fun main(){
    print(" Please enter your name:")
    val name = readLine()
    println("Hello $name welcome to my program! ")
    //Bonus:
    println(" Please enter your name:")
    var user_name = readLine()
    val msg = "Hello $user_name,welcome to my program!"
    println(msg)

}